document.addEventListener("DOMContentLoaded", function() {
    loadTasksFromLocalStorage();
    setupDragAndDrop();
});

function setupDragAndDrop() {
    const tasks = document.querySelectorAll('.task');
    const columns = document.querySelectorAll('.task-list');

    tasks.forEach(task => {
        task.setAttribute('draggable', true);
        task.addEventListener('dragstart', dragStart);
    });

    columns.forEach(column => {
        column.addEventListener('dragover', dragOver);
        column.addEventListener('drop', drop);
    });
}

function dragStart(e) {
    e.dataTransfer.setData('text/plain', e.target.id);
    e.target.style.opacity = '0.5';
}

function dragOver(e) {
    e.preventDefault();
}

function drop(e) {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('text/plain');
    const task = document.getElementById(taskId);
    
    if (task && e.target.classList.contains('task-list')) {
        e.target.appendChild(task);
        task.style.opacity = '1';
        updateTaskStateInLocalStorage(taskId, e.target.id);
    } else if (task && e.target.closest('.task-list')) {
        e.target.closest('.task-list').appendChild(task);
        task.style.opacity = '1';
        updateTaskStateInLocalStorage(taskId, e.target.closest('.task-list').id);
    }
}

function openForm() {
    var myModal = new bootstrap.Modal(document.getElementById('taskForm'));
    myModal.show();
}

function addTask(ev) {
    ev.preventDefault();
    var taskTitle = document.getElementById("taskTitle").value;
    var taskId = "task" + new Date().getTime();
    var taskElement = document.createElement("div");
    taskElement.className = "task card mb-2";
    taskElement.id = taskId;
    taskElement.innerHTML = `<div class="card-body">${taskTitle}</div>`;

    document.getElementById("todo-tasks").appendChild(taskElement);
    saveTaskToLocalStorage(taskId, taskTitle, "todo-tasks");
    setupDragAndDrop(); // Re-setup drag and drop for the new task
    var myModal = bootstrap.Modal.getInstance(document.getElementById('taskForm'));
    myModal.hide();
    document.getElementById("taskTitle").value = "";
}

function saveTaskToLocalStorage(taskId, taskTitle, taskState) {
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.push({ id: taskId, title: taskTitle, state: taskState });
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function loadTasksFromLocalStorage() {
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.forEach(task => {
        renderTask(task.id, task.title, task.state);
    });
}

function renderTask(taskId, taskTitle, taskState) {
    var taskElement = document.createElement("div");
    taskElement.className = "task card mb-2";
    taskElement.id = taskId;
    taskElement.innerHTML = `<div class="card-body">${taskTitle}</div>`;

    document.getElementById(taskState).appendChild(taskElement);
}

function updateTaskStateInLocalStorage(taskId, newState) {
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks = tasks.map(task => {
        if (task.id === taskId) {
            task.state = newState;
        }
        return task;
    });
    localStorage.setItem("tasks", JSON.stringify(tasks));
}